﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.NetworkInformation;
using System.Management;
using System.Net;
/*
	Purpose	: Program to find mainly the IP Address along with MAC Address and Computer Name
	Usage	: Create a Desktop Shortcut for the Exe .Whenever you want to copy your IP Address just double click the Shortcut.
			  You are Good to Go.
	Author 	: Vishnu Vasan Nehru
	Date	: 22.10.2013
	@		: vishnuvasan@vishnuvasan.com
*/

namespace Find_Your_IP
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string ComputerName = Dns.GetHostName();
            string MACAddress=string.Empty;
            IPHostEntry IPAddressList = (Dns.GetHostByName(ComputerName));
            IPAddress[] AllIPAddr = IPAddressList.AddressList;
            string IPAddress = AllIPAddr[AllIPAddr.Length - 1].ToString();

            // Function to Check the MAC Address
            NetworkInterface[] NetworkInterfaces = NetworkInterface.GetAllNetworkInterfaces();
            foreach (NetworkInterface adapter in NetworkInterfaces)
            { 
                if(MACAddress==String.Empty)
                {
                    IPInterfaceProperties properties = adapter.GetIPProperties();
                    MACAddress = adapter.GetPhysicalAddress().ToString();
                }
            }
            textBox1.Text = IPAddress;
            textBox2.Text = MACAddress;
            textBox3.Text = ComputerName;
        }

        private void label1_Click(object sender, EventArgs e)
        {
            
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
